/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package googlecodejam08;

import java.io.FileNotFoundException;
import java.util.Vector;
/**
 *
 * @author diogo
 */
public class SavingTheUniverse {
    TextScanner textFile;
    Vector<String> cases;
    int caseCount;
    
    
    public SavingTheUniverse(String string) throws FileNotFoundException {
        textFile = new TextScanner(string);
        caseCount = Integer.parseInt(textFile.getCurLine());
        cases = new Vector<String>();
        for(int x=0;x<caseCount;x++){
            this.solveCase(x+1);
            this.printCase(x);
        }
    }
    
    private void solveCase(int curCase){
        
        //initializes the case vars
        Vector<String> searchEngines;
        String[] queries;
        int[] counter;
        
        textFile.advanceLine();
        int x,limit = Integer.parseInt(textFile.getCurLine());
        searchEngines = new Vector<String>();
        counter = new int[limit];
        
        for (x=0;x<limit;x++){
            textFile.advanceLine();
            searchEngines.add(textFile.getCurLine());
        }
        
        textFile.advanceLine();
        limit = Integer.parseInt(textFile.getCurLine());
        queries = new String[limit];
        for (x=0;x<limit;x++){
            textFile.advanceLine();
            queries[x] = textFile.getCurLine();
        }
        
        int hits=0;
        boolean done = false;
        int startingPoint=0,lessSearched=-1;
        int minor;
        //solves
        while(!done){
            for (x=0;x<counter.length;x++){
                if (x!=lessSearched)
                    counter[x]=0;
                else
                    counter[x]=1000;
            }
            for (x=startingPoint;x<queries.length;x++){
                counter[searchEngines.indexOf(queries[x])]++;
            }
            minor= 500;
            for (x=0;x<counter.length;x++){
                if (counter[x]==0)
                    done= true;
                else if (counter[x]<minor) {
                    minor=counter[x];
                    lessSearched = x;
                }
            }
            for (x=startingPoint;x<queries.length;x++){
                if(queries[x].equals(searchEngines.get(lessSearched))){
                    startingPoint=x+1;
                    break;
                }
            }
            if (!done){
                hits++;
                //System.out.println("Hit - newSP "+startingPoint);
            }
        }
        
        //adds solution
        cases.add(String.valueOf(hits));
    }
    private void printCase(int curCase){
        System.out.println("Case #"+(curCase+1)+": "+cases.get(curCase));
    }
}

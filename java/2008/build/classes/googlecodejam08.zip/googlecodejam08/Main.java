/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package googlecodejam08;

import googlecodejam08.practice.*;
import java.io.FileNotFoundException;

/**
 *
 * @author diogo
 */
public class Main {

    /**
     * @param args the command line arguments
     */
    public static void main(String... aArgs) throws FileNotFoundException {
        //new AlienNumbers("/home/diogo/test.txt");
        //new AlwaysTurnLeft("/home/diogo/test.txt");
        //new InputGenerator(20,100,1000);
        new SavingTheUniverse("/home/diogo/test.txt");
        //new TriangleTrilemma("/home/diogo/test.txt");
    }

}
